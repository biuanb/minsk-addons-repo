from tmdbhelper.lib.files.ftools import cached_property
from tmdbhelper.lib.items.database.itemmeta_factories.concrete_classes.baseclass import BaseItem
from tmdbhelper.lib.items.database.itemmeta_factories.concrete_classes.baseroutes import MediaItemInfoLabelItemRoutes
from tmdbhelper.lib.addon.plugin import get_setting


class MediaItemArtworkRoutes:

    def __init__(self, parent_type=None):
        self.parent_type = parent_type

    routes = {
        'fanart_tv_poster': {
            'affixes': (None, 'language', 'english', 'null'),
            'outputs': 'poster',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'fanart_tv_landscape': {
            'affixes': (None, 'language', 'english'),
            'outputs': 'landscape',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'fanart_tv_clearlogo': {
            'affixes': (None, 'language', 'english', 'null'),
            'outputs': 'clearlogo',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'fanart_tv_fanart': {
            'affixes': (None, ),
            'outputs': 'fanart',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'fanart_tv_clearart': {
            'affixes': (None, ),
            'outputs': 'clearart',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'fanart_tv_discart': {
            'affixes': (None, ),
            'outputs': 'discart',
            'parents': (None, ),
            'ftv_api': True,
        },
        'fanart_tv_banner': {
            'affixes': (None, ),
            'outputs': 'banner',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': True,
        },
        'art_poster': {
            'affixes': (None, 'language', 'english', 'null'),
            'outputs': 'poster',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': False,
        },
        'art_landscape': {
            'affixes': (None, 'language', 'english'),
            'outputs': 'landscape',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': False,
        },
        'art_clearlogo': {
            'affixes': (None, 'language', 'english', 'null'),
            'outputs': 'clearlogo',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': False,
        },
        'art_fanart': {
            'affixes': (None, ),
            'outputs': 'fanart',
            'parents': (None, 'tvshow', 'season'),
            'ftv_api': False,
        },
        'art_thumbs': {
            'affixes': (None, ),
            'outputs': 'thumb',
            'parents': (None, ),
            'ftv_api': False,
        },
        'art_extrafanart': {
            'affixes': (None, ),
            'outputs': 'fanart',
            'parents': (None, ),
            'ftv_api': False,
        },
    }

    def get_art_list(self, affix=None, allow_ftv=False, allow_tmdb=False, no_affix=False):

        def get_art_tuple(route):
            definition = self.routes[route]
            if not allow_ftv and definition['ftv_api']:
                return
            if not allow_tmdb and not definition['ftv_api']:
                return
            if no_affix and len(definition['affixes']) != 1:
                return
            if affix not in definition['affixes']:
                return
            if self.parent_type not in definition['parents']:
                return
            art_route = f'{route}_{affix}' if affix is not None else route
            return ((art_route, self.parent_type), definition['outputs'])

        return [
            i for i in (
                get_art_tuple(route)
                for route in self.routes.keys())
            if i]

    def get_art_list_language(self, allow_ftv=False, allow_tmdb=False):
        return self.get_art_list('language', allow_ftv=allow_ftv, allow_tmdb=allow_tmdb)

    def get_art_list_english(self, allow_ftv=False, allow_tmdb=False):
        return self.get_art_list('english', allow_ftv=allow_ftv, allow_tmdb=allow_tmdb)

    def get_art_list_null(self, allow_ftv=False, allow_tmdb=False):
        return self.get_art_list('null', allow_ftv=allow_ftv, allow_tmdb=allow_tmdb)

    def get_art_list_extra(self, allow_ftv=False, allow_tmdb=False):
        return self.get_art_list(None, allow_ftv=allow_ftv, allow_tmdb=allow_tmdb, no_affix=True)

    def get_art_list_tmdb_preferred(self, affix=None):
        return self.get_art_list(affix, allow_tmdb=True) + self.get_art_list(affix, allow_ftv=True)

    def get_art_list_ftv_preferred(self, affix=None):
        return self.get_art_list(affix, allow_ftv=True) + self.get_art_list(affix, allow_tmdb=True)

    def get_art_list_tmdb_language(self):
        return self.get_art_list_extra(allow_ftv=True, allow_tmdb=True) \
            + self.get_art_list_language(allow_tmdb=True) \
            + self.get_art_list_language(allow_ftv=True) \
            + self.get_art_list_english(allow_tmdb=True) \
            + self.get_art_list_english(allow_ftv=True) \
            + self.get_art_list_null(allow_tmdb=True) \
            + self.get_art_list_null(allow_ftv=True)

    def get_art_list_ftv_language(self):
        return self.get_art_list_extra(allow_ftv=True, allow_tmdb=True) \
            + self.get_art_list_language(allow_ftv=True) \
            + self.get_art_list_language(allow_tmdb=True) \
            + self.get_art_list_english(allow_ftv=True) \
            + self.get_art_list_english(allow_tmdb=True) \
            + self.get_art_list_null(allow_ftv=True) \
            + self.get_art_list_null(allow_tmdb=True)

    @property
    def configured_routes(self):
        if not get_setting('fanarttv_lookup'):
            return self.get_art_list(allow_tmdb=True)
        if not get_setting('language_lookup'):
            if get_setting('fanarttv_prefer'):
                return self.get_art_list_ftv_preferred()
            return self.get_art_list_tmdb_preferred()
        if not get_setting('fanarttv_prefer'):
            return self.get_art_list_tmdb_language()
        return self.get_art_list_ftv_language()


class MediaItem(BaseItem):

    @property
    def art_dbclist_routes(self):
        return MediaItemArtworkRoutes().configured_routes

    infolabels_dbclist_routes = (
        (('genre', None), 'name', 'genre'),
        (('country', None), 'name', 'country'),
        (('director', None), 'name', 'director'),
        (('writer', None), 'name', 'writer'),
    )

    infolabels_dbcitem_routes = (
        MediaItemInfoLabelItemRoutes.certification,
        MediaItemInfoLabelItemRoutes.trailer,
    )

    """
    instance: tuple of (attr, subtype) to retrieve self.db_{attr}_{subtype}_cache
    mappings: dictionary of {property_name: database_key} to map list as ListItem.Property({property_prefix}.{x}.{property_name}) = database[database_key]
    propname: tuple of property_prefix(es) to add values to (used mostly for backwards compatibility where multiple props reference same data)
    joinings: optional tuple of (property_name, dictionary_key) to map slash separated and [CR] separated properties as ListItem.Property(name), ListItem.Property(name_CR) e.g. 'Action / Adventure' 'Action[CR]Adventure'
    """
    infoproperties_dbclist_routes = (
        {
            'instance': ('genre', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id'},
            'propname': ('genre', ),
            'joinings': None
        },
        {
            'instance': ('country', None),
            'mappings': {'name': 'name', 'iso_country': 'iso_country'},
            'propname': ('country', ),
            'joinings': None
        },
        {
            'instance': ('studio', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'icon': 'logo', 'country': 'country'},
            'propname': ('studio', ),
            'joinings': None
        },
        {
            'instance': ('provider', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'type': 'availability', 'icon': 'logo'},
            'propname': ('provider', ),
            'joinings': ('providers', 'name')
        },
        {
            'instance': ('castmember', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'role': 'role', 'character': 'role', 'thumb': 'thumb'},
            'propname': ('cast', ),
            'joinings': ('cast', 'name')
        },
        {
            'instance': ('crewmember', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('crew', ),
            'joinings': ('crew', 'name')
        },
        {
            'instance': ('creator', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('creator', ),
            'joinings': ('creator', 'name')
        },
        {
            'instance': ('director', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('director', ),
            'joinings': ('director', 'name')
        },
        {
            'instance': ('writer', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('writer', ),
            'joinings': ('writer', 'name')
        },
        {
            'instance': ('screenplay', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('screenplay', ),
            'joinings': ('screenplay', 'name')
        },
        {
            'instance': ('producer', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('producer', ),
            'joinings': ('producer', 'name')
        },
        {
            'instance': ('sound_department', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('sound_department', ),
            'joinings': ('sound_department', 'name')
        },
        {
            'instance': ('art_department', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('art_department', ),
            'joinings': ('art_department', 'name')
        },
        {
            'instance': ('photography', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('photography', ),
            'joinings': ('photography', 'name')
        },
        {
            'instance': ('editor', None),
            'mappings': {'name': 'name', 'tmdb_id': 'tmdb_id', 'department': 'department', 'role': 'role', 'job': 'role', 'thumb': 'thumb'},
            'propname': ('editor', ),
            'joinings': ('editor', 'name')
        },
    )

    def get_infoproperties_custom(self, infoproperties):
        for i in self.parent_db_cache.return_basemeta_db('custom').cached_data:
            infoproperties[i['key']] = i['value']
        return infoproperties

    def get_infoproperties_progress(self, infoproperties):
        duration = self.get_data_value('duration')
        if not duration:
            return infoproperties

        progress = self.get_instance_cached_data_value(self.parent_db_cache.return_basemeta_db('playprogress'), 'playback_progress')
        if not progress or progress < 4 or progress > 96:
            progress = 0

        infoproperties['ResumeTime'] = int(duration * progress // 100)
        infoproperties['TotalTime'] = int(duration)
        return infoproperties

    def get_unique_ids(self, unique_ids):
        for i in (self.parent_db_cache.return_basemeta_db('unique_id').cached_data or ()):
            unique_ids[i['key']] = i['value']
        unique_ids['tmdb'] = self.parent_db_cache.tmdb_id
        return unique_ids

    @cached_property
    def cast(self):
        return [
            {
                'name': i['name'],
                'role': i['role'],
                'order': i['ordering'] or 999999,
                'thumbnail': self.parent_db_cache.common_apis.tmdb_imagepath.get_imagepath_poster(i['thumb'])
            }
            for i in self.parent_db_cache.return_basemeta_db('castmember').cached_data
        ]
